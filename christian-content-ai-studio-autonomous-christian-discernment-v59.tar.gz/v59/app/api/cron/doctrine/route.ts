import { NextResponse } from 'next/server'
import { getScriptureKnowledge } from '@/lib/scripture-intelligence'
import { getBiblicalTheology } from '@/lib/biblical-theology'
import { getBiblicalDoctrine, reviewBiblicalDoctrine, saveBiblicalDoctrine, validateBiblicalDoctrine } from '@/lib/biblical-doctrine'
import { getScriptureHermeneutics } from '@/lib/scripture-hermeneutics'

export async function GET(req: Request) {
  if (req.headers.get('authorization') !== `Bearer ${process.env.AUTOPILOT_SECRET}`) return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 401 })
  try {
    const scripture = await getScriptureKnowledge()
    const theology = await getBiblicalTheology()
    const hermeneutics = await getScriptureHermeneutics()
    if (!scripture || !theology || !hermeneutics) return NextResponse.json({ ok: false, status: 'WAITING_FOR_DEPENDENCIES' })
    const review = await reviewBiblicalDoctrine({ reference: scripture.primaryReference, intendedClaim: theology.thesis, scripture, hermeneutics, canonicalTheology: theology })
    const validation = validateBiblicalDoctrine(review)
    if (validation.ok) await saveBiblicalDoctrine(review)
    return NextResponse.json({ ok: validation.ok, review, validation })
  } catch (error) { return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : 'Doctrine cron failed.' }, { status: 500 }) }
}
