import { NextResponse } from 'next/server'
import { getScriptureKnowledge } from '@/lib/scripture-intelligence'
import { getScriptureInterpretation } from '@/lib/scripture-interpretation'
import { getBiblicalDoctrine } from '@/lib/biblical-doctrine'
import { reviewChristCenteredGospel, saveChristCenteredGospel, validateChristCenteredGospel } from '@/lib/christ-centered-gospel'

export async function GET(req: Request) {
  if (req.headers.get('authorization') !== `Bearer ${process.env.AUTOPILOT_SECRET}`) return NextResponse.json({ ok: false, error: 'Unauthorized' }, { status: 401 })
  try {
    const scripture = await getScriptureKnowledge()
    const interpretation = await getScriptureInterpretation()
    const doctrine = await getBiblicalDoctrine()
    if (!scripture || !interpretation || !doctrine) return NextResponse.json({ ok: false, status: 'WAITING_FOR_DEPENDENCIES' })
    const review = await reviewChristCenteredGospel({ reference: scripture.primaryReference, intendedClaim: doctrine.doctrinalThesis, scripture, interpretation, doctrine })
    const validation = validateChristCenteredGospel(review)
    if (validation.ok) await saveChristCenteredGospel(review)
    return NextResponse.json({ ok: validation.ok, review, validation })
  } catch (error) { return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : 'Gospel cron failed.' }, { status: 500 }) }
}
